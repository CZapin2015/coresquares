# CoreSquares Website

This is the Astro-based CoreSquares website.

## Scripts

- `npm install`
- `npm run dev` to start local dev server
- `npm run build` to build for production
- `npm run preview` to preview the production build

## Project Structure

- `src/pages/` - your site pages (Home, About, Services, Contact)
- `src/components/` - shared components (Head, Header, Footer)
- `src/layouts/` - site layout wrapper
- `public/` - static assets (favicon, etc.)
